import React from "react";

function About() {
  return (
    <span>
      About this page: I built it because I love movies. 한글도 써보자
    </span>
  );
}

export default About;
